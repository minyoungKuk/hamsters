export function openDetailPage(moviId){
    console.log(moviId);
    location.href=`/pages/detail.html?movieId=${moviId}`
}