export function openDetailPage(moviId){
    location.href=`/pages/detail.html?movieId=${moviId}`
}